package com.Bookmyshow.experience;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowExperienceApplicationTests {

	@Test
	void contextLoads() {
	}

}
